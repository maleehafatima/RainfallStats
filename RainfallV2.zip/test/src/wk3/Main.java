package wk3;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(final String[] args) {

        // read data
        final Scanner console = new Scanner(System.in);
        final List<Double> rainfall = new ArrayList<>(); // list to store days' rainfall
        while (console.hasNextDouble()) {    // read/store each day's rainfall
            final double value = console.nextDouble();
            rainfall.add(value);
            final int pos = rainfall.size() - 1;
            System.out.println("rainfall[" + pos + "] = " + value);
        }
        final RainfallStats result = RainfallV2.calculateStats(rainfall);
        // report results
        final RainfallStats calculateStats = RainfallV2.calculateStats(rainfall);
       /* if(result.size == 0){
            System.out.println("This list is empty. Enter nonnegative integers.");
        }
        else { */
            System.out.println("Size: " + result.size);
            System.out.printf("Average rainfall = %.1f\n", result.average); //result.average
            System.out.println("Cumulative rainfall: " + result.cumulative);
            System.out.println(result.daysAbove + " days above average");
            System.out.println(result.dryDays + " dry days");
   //     }
    }
}
