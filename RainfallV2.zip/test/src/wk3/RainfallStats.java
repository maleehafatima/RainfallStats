package wk3;

import java.util.List;

public class RainfallStats {
   public RainfallStats(final int size, final double cumulative, final double average, final int daysAbove, final int dryDays) {
       this.size = size;
       this.average = average;
       this.cumulative = cumulative;
       this.daysAbove = daysAbove;
       this.dryDays = dryDays;
   }
   public final int size;
   public final double average;
   public final double cumulative;
   public final int daysAbove;
   public final int dryDays;
}
