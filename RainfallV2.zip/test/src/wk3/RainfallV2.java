package wk3;

import java.util.List;

public class RainfallV2 {
    public static RainfallStats calculateStats(final List<Double> rainfall) {
    if (rainfall.size() == 0)
        throw new IllegalArgumentException("This list is empty. Enter nonnegative integers.");
        //remove negative numbers from the array list
        for (int i=rainfall.size() - 1; i >= 0; i--){
            if(rainfall.get(i) < 0)
            rainfall.remove(i);
        }

        //calculate the cumulative rainfall
        final int size = rainfall.size();
        double sum = 0;
        for (final double current : rainfall) {    // read/store each day's rainfall
            sum += current;
        }
        final double cumulative = sum;

        //calculate the average rainfall
        final double average = sum / rainfall.size();

        // see how many days are above average
        int count = 0;
        for (final double current : rainfall) {
            if (current > average) {
                count++;
            }
        }
        final int daysAbove = count;

        // see how many days are under 5% of avg
        int number = 0;
        double percentile = average * 0.05;
        for (final double current : rainfall) {
            if (current < percentile) {
                number++;
            }
        }
        final int dryDays = number;

        return new RainfallStats(size, cumulative, average, daysAbove, dryDays);
    }


}
