package wk3;

import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.*;

public class RainfallV2Test {
    final static double DELTA = 0.000000001;


    @Test
    public void testRainfallV2() {
        final List<Double> rainfall = Arrays.asList(3.4);
        final RainfallStats actual = RainfallV2.calculateStats(rainfall);
        assertEquals(1, actual.size);
        assertEquals(3.4, actual.cumulative, DELTA);
        assertEquals(3.4, actual.average, DELTA);
        assertEquals(0, actual.daysAbove);
        assertEquals(0, actual.dryDays);
    }

    @Test
    public void testRainfallV23() {
        final List<Double> rainfall = Arrays.asList(1.0, 2.0, 3.0, 4.0, 0.0);
        final RainfallStats actual = RainfallV2.calculateStats(rainfall);
        assertEquals(5, actual.size);
        assertEquals(10.0, actual.cumulative, DELTA);
        assertEquals(2.0, actual.average, DELTA);
        assertEquals(2, actual.daysAbove);
        assertEquals(1, actual.dryDays);
    }

    @Test
    public void testRainfallV24() {
        final List<Double> rainfall = Arrays.asList(0.0);
        final RainfallStats actual = RainfallV2.calculateStats(rainfall);
        assertEquals(1, actual.size);
        assertEquals(0.0, actual.cumulative, DELTA);
        assertEquals(0.0, actual.average, DELTA);
        assertEquals(0, actual.daysAbove);
        assertEquals(0, actual.dryDays);
    }


    // all of my failed attempts to test the empty arraylist due to negative inputs

    @Test(expected = IndexOutOfBoundsException.class)
    public void empty() {
        new ArrayList<Double>().get(0);
    }

     /* @Test(expected = IllegalArgumentException.class)
    public void testRainfallV25() {
        final List<Double> rainfall = Arrays.asList(-1.0, -2.0);
        final RainfallStats actual = RainfallV2.calculateStats(rainfall);
    }  */
    /*@Test
    public void testRainfallV25() {
        final List<Double> rainfall = Arrays.asList(-1.0, -2.0);
        final RainfallStats actual = RainfallV2.calculateStats(rainfall);
        assertTrue("This list is empty. Enter nonnegative integers.", true);
    } */


   /* @Test
    public void testRainfallV25() {
        final List<Double> rainfall = new ArrayList<>(Arrays.asList(-1.0, -2.0));
        final RainfallStats actual = RainfallV2.calculateStats(rainfall);
        assertEquals(0, actual.size);
        assertEquals(0.0, actual.cumulative, DELTA);
        assertEquals(0.0, actual.average, DELTA);
        assertEquals(0, actual.daysAbove);
        assertEquals(0, actual.dryDays);
    } */


  /* @Test
   public void return_empty_set_java () {

       List<Double> emptySet = RainfallV2.emptySet();

       assertTrue(emptySet.isEmpty());
   } */
}

