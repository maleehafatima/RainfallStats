Why do we have to store the input items to provide the required functionality?
- We store the values so that they become easily accesible when running through all of the various statistical calculations.

Why does the user no longer need to specify the item count up front?
- Because of the use of ArrayLists there is no need to specify item count because ArrayLists are resizable.

What is the key capability of Java lists, such as ArrayList, that makes it a better choice for this solution than basic native arrays?
- ArrayLists can be resized whereas arrays are of one constant size. This would become an issue in this particular program because we remove negative numbers from the ArrayList.

What is the purpose of the RainfallStats class in terms of helping with maintainability and testability?
- The RainfallStats class is a place to store the calculated statistics while the code is running and also makes the Main mathod look cleaner when trying to print out the statistics.

Why does the core method need to take a List instead of just an ArrayList?
- Using a more general List allows the code to be more flexible than it would be if using a specific implementation ArrayList.